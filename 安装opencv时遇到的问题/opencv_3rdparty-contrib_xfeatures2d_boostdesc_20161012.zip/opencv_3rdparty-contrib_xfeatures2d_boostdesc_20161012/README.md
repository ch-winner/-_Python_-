
**BoostDesc descriptor generated headers**

 Following files are generated from original binaries [1] using ```export-boostdesc.py``` tool.

* boostdesc_bgm.i (bgm.bin)
* boostdesc_bgm_bi.i (bgm_bilinear.bin)
* boostdesc_bgm_hd.i (bgm_hard.bin)
* boostdesc_binboost_064.i (binboost.bin)
* boostdesc_binboost_128.i (binboost_128.bin)
* boostdesc_binboost_256.i (binboost_256.bin)
* boostdesc_lbgm.i (lbgm.bin)
