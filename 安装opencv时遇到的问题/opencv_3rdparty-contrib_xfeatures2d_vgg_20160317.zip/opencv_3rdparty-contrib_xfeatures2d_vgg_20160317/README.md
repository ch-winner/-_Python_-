
**VGG  descriptor generated headers**

 Following files are generated within DLCO framework [1]
* vgg_generated_120.i (120 dim PR&PJ matrices)
* vgg_generated_80.i (80 dim PR&PJ matrices)
* vgg_generated_64.i (64 dim PR&PJ matrices)
* vgg_generated_48.i (48 dim PR&PJ matrices)

[1] https://github.com/cbalint13/opencv-dlco/tree/master/workspace/opencv
